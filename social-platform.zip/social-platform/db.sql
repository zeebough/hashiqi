-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sp
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `game_info`
--

DROP TABLE IF EXISTS `game_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_info` (
  `gameId` bigint unsigned NOT NULL,
  `gameName` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`gameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_info`
--

LOCK TABLES `game_info` WRITE;
/*!40000 ALTER TABLE `game_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genshin`
--

DROP TABLE IF EXISTS `genshin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `genshin` (
  `userId` bigint unsigned NOT NULL,
  `zone` varchar(16) DEFAULT NULL,
  `characters` varchar(1024) DEFAULT NULL,
  `worldLevel` tinyint unsigned DEFAULT NULL,
  `adventureLevel` tinyint unsigned DEFAULT NULL,
  `resouceSharable` tinyint DEFAULT NULL,
  `des` varchar(480) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genshin`
--

LOCK TABLES `genshin` WRITE;
/*!40000 ALTER TABLE `genshin` DISABLE KEYS */;
/*!40000 ALTER TABLE `genshin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lol`
--

DROP TABLE IF EXISTS `lol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lol` (
  `userId` bigint unsigned NOT NULL,
  `zone` varchar(20) DEFAULT NULL,
  `gameId` varchar(32) DEFAULT NULL,
  `psn` varchar(8) DEFAULT NULL,
  `ranking` char(16) DEFAULT NULL,
  `des` varchar(480) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lol`
--

LOCK TABLES `lol` WRITE;
/*!40000 ALTER TABLE `lol` DISABLE KEYS */;
INSERT INTO `lol` VALUES (1,'祖安','我ri你仙人','打野，上单','最强王者','你是一个一个一个王者啊啊啊啊啊啊'),(2,'无畏先锋','富婆v50','射手，打野','英勇青铜','求雷普，周五会员制餐厅上分dd'),(333,'祖安','v专第一辅助','辅助，射手','璀璨钻石',NULL),(1550335344883388418,'无畏先锋','清朝老兵背行囊','上单','最强王者','大哥带飞');
/*!40000 ALTER TABLE `lol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mc`
--

DROP TABLE IF EXISTS `mc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mc` (
  `userId` bigint unsigned NOT NULL,
  `tags` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mc`
--

LOCK TABLES `mc` WRITE;
/*!40000 ALTER TABLE `mc` DISABLE KEYS */;
/*!40000 ALTER TABLE `mc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token_blacklist`
--

DROP TABLE IF EXISTS `token_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `token_blacklist` (
  `tokenId` bigint unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL,
  PRIMARY KEY (`tokenId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_blacklist`
--

LOCK TABLES `token_blacklist` WRITE;
/*!40000 ALTER TABLE `token_blacklist` DISABLE KEYS */;
INSERT INTO `token_blacklist` VALUES (1,'ttt');
/*!40000 ALTER TABLE `token_blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `userId` bigint unsigned NOT NULL,
  `nickName` varchar(32) DEFAULT NULL,
  `realName` varchar(32) DEFAULT NULL,
  `pwd` varchar(256) DEFAULT NULL,
  `phone` char(11) DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `sex` varchar(8) DEFAULT '保密',
  `height` smallint DEFAULT NULL,
  `weight` smallint DEFAULT NULL,
  `country` varchar(32) DEFAULT NULL,
  `province` varchar(32) DEFAULT NULL,
  `city` varchar(32) DEFAULT NULL,
  `district` varchar(32) DEFAULT NULL,
  `school` varchar(64) DEFAULT NULL,
  `campus` varchar(20) DEFAULT NULL,
  `college` varchar(64) DEFAULT NULL,
  `major` varchar(64) DEFAULT NULL,
  `isPrivate` tinyint DEFAULT '0',
  `isHomo` tinyint DEFAULT '0',
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'van','darkholme','114514','13013013013',0,'保密',183,80,'美国','马萨诸塞州',NULL,NULL,'麻省理工学院',NULL,NULL,NULL,0,0),(2,'kouji','tadokoro','1919810','15115115115',0,'保密',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0),(333,'tiansuo',NULL,'121564','17817817817',0,'保密',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0),(1550335344883388418,'tadokorov',NULL,'henghenghengawula123','13913913913',0,'保密',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0),(1556505010295017474,'什么东西','糟心','nishiyige1919','11111111111',0,'保密',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_game`
--

DROP TABLE IF EXISTS `user_game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_game` (
  `userId` bigint unsigned NOT NULL,
  `gameId` bigint unsigned NOT NULL,
  `isPrivate` tinyint DEFAULT '0',
  PRIMARY KEY (`userId`,`gameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_game`
--

LOCK TABLES `user_game` WRITE;
/*!40000 ALTER TABLE `user_game` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_hold_blacklist`
--

DROP TABLE IF EXISTS `user_hold_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_hold_blacklist` (
  `holderId` bigint unsigned NOT NULL,
  `memberId` bigint unsigned NOT NULL,
  PRIMARY KEY (`holderId`,`memberId`),
  KEY `holderId` (`holderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_hold_blacklist`
--

LOCK TABLES `user_hold_blacklist` WRITE;
/*!40000 ALTER TABLE `user_hold_blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_hold_blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wang_zhe`
--

DROP TABLE IF EXISTS `wang_zhe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wang_zhe` (
  `userId` bigint unsigned NOT NULL,
  `zone` varchar(20) DEFAULT NULL,
  `gameId` varchar(32) DEFAULT NULL,
  `psn` varchar(8) DEFAULT NULL,
  `ranking` char(16) DEFAULT NULL,
  `des` varchar(480) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wang_zhe`
--

LOCK TABLES `wang_zhe` WRITE;
/*!40000 ALTER TABLE `wang_zhe` DISABLE KEYS */;
/*!40000 ALTER TABLE `wang_zhe` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 14:11:16
