package com.ghtt.socialplatform.controller.innerController;

import com.ghtt.socialplatform.controller.Code;
import com.ghtt.socialplatform.controller.Result;
import com.ghtt.socialplatform.controller.exceptions.BusinessException;
import com.ghtt.socialplatform.global.ServerProperties;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class RefreshController {
    @PostMapping("/refresh")
    public Result refreshToken(@RequestHeader(name="Referer") String referer, @RequestAttribute String newToken) {
        Assert.notNull(referer,"非法调用");
        if(!ServerProperties.INTERNAL_SERVER_REQUEST.equals(referer)){
            throw new BusinessException(Code.ILLEGAL_ACCESS,"非法调用"+this.getClass().getName());
        }
        Assert.notNull(newToken,"非法调用");
        return new Result(Code.SELECT_OK,"newToken",newToken);
    }
}
