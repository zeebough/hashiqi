package com.ghtt.socialplatform.service.gameService;

public interface GameServiceFactory {
    GameService getGameService(String gameName)throws Exception;
}
