package com.ghtt.socialplatform.controller;


import com.ghtt.socialplatform.controller.exceptions.BusinessException;
import com.ghtt.socialplatform.domain.User;
import com.ghtt.socialplatform.domain.multitable.UserHoldBlacklist;
import com.ghtt.socialplatform.service.TokenService;
import com.ghtt.socialplatform.service.UserHoldBlacklistService;
import com.ghtt.socialplatform.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.List;

/*
Id代表自己的userId,ID代表被操作对象的userId
 */

@Slf4j
@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private UserHoldBlacklistService userHoldBlacklistService;
    @PostMapping("/login")
    public Result login(@RequestHeader(value = "phone")String phone,
                        @RequestHeader(value = "password")String password){
        //传入参数时，若header中属性未填写，则传入的值为“”
        User user=userService.login(phone,password);
        String token=tokenService.getToken(user);
        String refreshToken=tokenService.getRefreshToken(user);
        return new Result(Code.SELECT_OK,"登录成功",new String[]{token, refreshToken});
    }

    @PostMapping("/register")
    public Result register(HttpServletRequest request) throws UnsupportedEncodingException {
        request.setCharacterEncoding("UTF-8");
        String phone=request.getHeader("phone");
        String password=request.getHeader("password");
        String nickName=request.getParameter("nickName");

        userService.register(phone,password,nickName);
        return new Result(Code.INSERT_OK,"注册成功");
        //TODO:前端跳转到/login
    }

    @PostMapping("/privacy/{isPrivate}")
    public Result setPrivacy(@PathVariable String isPrivate,@RequestAttribute String userId){
        Integer p =Integer.valueOf(isPrivate);
        if (!p.equals(0)&&!p.equals(1))throw new BusinessException(Code.ILLEGAL_INPUT,"非法参数");
        int rows=0;
        if (p.equals(0)) rows=userService.setPublic(Long.valueOf(userId));
        if (p.equals(1)) rows=userService.setPrivate(Long.valueOf(userId));
        if (rows<1)throw new BusinessException(Code.UPDATE_ERR,"修改隐私设置失败");
        return new Result(Code.INSERT_OK,"修改隐私设置成功");
    }

    @PostMapping()
    public Result selectAll(HttpServletRequest request){
        String userId=request.getAttribute("userId").toString();
        if(null==request.getSession().getAttribute(userId+"selectAllUsersCurrentPage")) {
            request.getSession().setAttribute(userId + "selectAllUsersCurrentPage", 0L);
        }
        List<User> allUser = userService.selectAllUsers((Long)request.getSession()
                        .getAttribute(userId + "selectAllUsersCurrentPage"), 200L);
        return new Result(Code.SELECT_OK,null,allUser);
    }

    //查其他用户
    @PostMapping("/{userID}")
    public Result selectUserById(@PathVariable String userID){
        User user=userService.selectUserById(Long.valueOf(userID));
        if(null==user)return new Result(Code.SELECT_OK,"什么也没有找到");
        return new Result(Code.SELECT_OK,null,user);
    }

    @PostMapping("/name/{userName}")
    public Result selectUserByName(@PathVariable String userName){
        List<User> users= userService.selectUserByName(userName);
        if(users.size()<1)return new Result(Code.SELECT_OK,"什么也没有找到");
        return new Result(Code.SELECT_OK,null,users);
    }

    @PutMapping()
    public Result updateUserById(@RequestAttribute String userId,HttpServletRequest request) throws IllegalAccessException {
        User userForUpdate=new User(Long.valueOf(userId));
        Iterator<String> paramNames=request.getParameterNames().asIterator();
        if(!paramNames.hasNext())return new Result(Code.UPDATE_ERR,"更新失败，请填写要更新的值");
        for (String key=paramNames.next();paramNames.hasNext();) {
            Field field;
            try{
                field = userForUpdate.getClass().getDeclaredField(key);
            }catch (NoSuchFieldException e){
                continue;
            }
            field.setAccessible(true);
            if(field.getType().equals(Long.class)){
                field.set(userForUpdate,Long.valueOf(request.getParameter(key)));
                continue;
            }
            field.set(userForUpdate,request.getParameter(key));
        }
        if(userService.updateUserById(userForUpdate)<1) return new Result(Code.UPDATE_ERR,"更新失败，请稍后再试");
        return new Result(Code.UPDATE_OK,"更新成功");
    }

    @PatchMapping()
    public Result updatePartUserById(@RequestAttribute String userId,HttpServletRequest request) throws IllegalAccessException {
        User entity= userService.selectUserById(Long.valueOf(userId));
        Iterator<String> paramNames=request.getParameterNames().asIterator();
        if(!paramNames.hasNext())return new Result(Code.UPDATE_ERR,"更新失败，请填写要更新的值");
        for (String key=paramNames.next();paramNames.hasNext();) {
            Field field;
            try{
                field = entity.getClass().getDeclaredField(key);
            }catch (NoSuchFieldException e){
                continue;
            }
            field.setAccessible(true);
            if(field.getType().equals(Long.class)){
                field.set(entity,Long.valueOf(request.getParameter(key)));
                continue;
            }
            field.set(entity,request.getParameter(key));
        }
        if(userService.updateUserById(entity)<1) return new Result(Code.UPDATE_ERR,"更新失败，请稍后再试");
        return new Result(Code.UPDATE_OK,"更新成功");
    }

    @PostMapping("/hello")
    public Result hello(){
        return new Result(Code.SELECT_OK,"hello","haha");
    }

    @PostMapping("/blacklist/{userID}")
    public Result add2Blacklist(@RequestAttribute String userId,@PathVariable String userID){
        Assert.notNull(userId,"空userId");
        Assert.notNull(userID,"空userID");
        if(userHoldBlacklistService.add2Blacklist(new UserHoldBlacklist(Long.valueOf(userId),Long.valueOf(userID)))<0)
            throw new BusinessException(Code.INSERT_ERR,"添加黑名单失败，请稍后再试");
        return new Result(Code.INSERT_OK,"添加黑名单成功");
    }

    @DeleteMapping("/blacklist/{userID}")
    public Result deleteFromBlacklist(@RequestAttribute String userId,@PathVariable String userID){
        Assert.notNull(userId,"空userId");
        Assert.notNull(userID,"空userID");
        if(userHoldBlacklistService.deleteFromBlacklist(new UserHoldBlacklist(Long.valueOf(userId),Long.valueOf(userID)))<0)
            throw new BusinessException(Code.DELETE_ERR,"删除黑名单，请稍后再试");
        return new Result(Code.DELETE_OK,"删除黑名单成功");
    }

    @PostMapping("/blacklist")
    public Result selectBlacklist(@RequestAttribute String userId){
        Assert.notNull(userId,"空userId");
        return new Result(Code.INSERT_OK,null,userHoldBlacklistService.selectBlackListById(Long.valueOf(userId)));
    }
}
