package com.ghtt.socialplatform.controller;

import com.ghtt.socialplatform.controller.exceptions.BusinessException;
import com.ghtt.socialplatform.domain.multitable.UserGame;
import com.ghtt.socialplatform.service.GameInfoService;
import com.ghtt.socialplatform.service.UserGameService;
import com.ghtt.socialplatform.service.gameService.GameService;
import com.ghtt.socialplatform.service.gameService.GameServiceFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
@Slf4j
@RestController
@RequestMapping("/game")
public class GameController {
    @Autowired
    private GameServiceFactory factory;
    @Autowired
    private GameInfoService gameInfoService;
    @Autowired
    private UserGameService userGameService;

    @PostMapping("/gameName/{gameName}/{operation}")
    @SuppressWarnings("unchecked")
    public Result dispatchGameService(@PathVariable("gameName") String gameName, @PathVariable("operation") String operation, HttpServletRequest request) throws Exception {

        Map<String, String> params = new ConcurrentHashMap<>();

        for (Iterator<String> it = request.getParameterNames().asIterator(); it.hasNext(); ) {
            String key = it.next();
            String value = request.getParameter(key);
            params.put(key, value);
        }
        params.put("userId", request.getAttribute("userId").toString());

        GameService service = factory.getGameService(gameName);
        service.setParams(params);
        Long gameId=gameInfoService.selectGameIdByName(gameName);
        Result res = new Result();
        switch (operation) {
            case "add" -> {
                int rowsAffected = service.addPlayer();
                int rows= userGameService.addGame(new UserGame(Long.valueOf(params.get("userId")),gameId));
                if (rowsAffected > 0&&rows>0) {
                    res.setCode(Code.INSERT_OK);
                    res.setMsg("添加成功");
                } else throw new BusinessException(Code.INSERT_ERR, "添加失败，请稍后再试");
            }
            case "delete" -> {
                int rowsAffected = service.deletePlayer();
                int rows= userGameService.deleteGame(new UserGame(Long.valueOf(params.get("userId")),gameId));
                if (rowsAffected > 0&&rows>0) {
                    res.setCode(Code.DELETE_OK);
                    res.setMsg("删除成功");
                } else throw new BusinessException(Code.DELETE_ERR, "删除失败，请稍后再试");
            }
            case "update" -> {
                if(service.updatePlayer()>0){
                    res.setCode(Code.UPDATE_OK);
                    res.setMsg("更新成功");
                }else throw new BusinessException(Code.UPDATE_ERR,"更新失败，请稍后再试");
            }
            case "select" -> {
                List data = service.selectPlayer();
                res.setCode(Code.SELECT_OK);
                if(data.size()<1)res.setMsg("未找到符合条件的玩家");
                res.setMsg("共找到" + data.size() + "位玩家");
                res.setData(data);
            }
            default -> throw new BusinessException(Code.UNKNOWN_ERR, "服务器繁忙，请您稍后再试");
        }
        return res;
    }

    @PostMapping("/gameId/{gameId}/{operation}")
    @Transactional(rollbackFor = Exception.class)
    public Result dispatchGameService(@PathVariable("gameId") Long gameId, @PathVariable("operation") String operation, HttpServletRequest request) throws Exception {

        Map<String, String> params = new ConcurrentHashMap<>();

        for (Iterator<String> it = request.getParameterNames().asIterator(); it.hasNext(); ) {
            String key = it.next();
            String value = request.getParameter(key);
            params.put(key, value);
        }
        params.put("userId", request.getAttribute("userId").toString());
        String gameName = gameInfoService.selectGameNameById(gameId);
        GameService service = factory.getGameService(gameName);
        service.setParams(params);
        Result res = new Result();
        switch (operation) {
            case "add" -> {
                int rowsAffected = service.addPlayer();
                int rows= userGameService.addGame(new UserGame(Long.valueOf(params.get("userId")),gameId));
                if (rowsAffected > 0&&rows>0) {
                    res.setCode(Code.INSERT_OK);
                    res.setMsg("添加成功");
                } else throw new BusinessException(Code.INSERT_ERR, "添加失败，请稍后再试");
            }
            case "delete" -> {
                int rowsAffected = service.deletePlayer();
                int rows= userGameService.deleteGame(new UserGame(Long.valueOf(params.get("userId")),gameId));
                if (rowsAffected > 0&&rows>0) {
                    res.setCode(Code.DELETE_OK);
                    res.setMsg("删除成功");
                } else throw new BusinessException(Code.DELETE_ERR, "删除失败，请稍后再试");
            }
            case "update" -> {
                if(service.updatePlayer()>0){
                    res.setCode(Code.UPDATE_OK);
                    res.setMsg("更新成功");
                }else throw new BusinessException(Code.UPDATE_ERR,"更新失败，请稍后再试");
            }
            case "select" -> {
                List data = service.selectPlayer();
                res.setCode(Code.SELECT_OK);
                res.setMsg("共查询到" + data.size() + "位玩家");
                res.setData(data);
            }
            default -> throw new BusinessException(Code.UNKNOWN_ERR, "服务器繁忙，请您稍后再试");
        }
        return res;
    }
}