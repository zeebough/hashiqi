package com.ghtt.socialplatform.dao.gameDao;


public interface GameDao {
}
