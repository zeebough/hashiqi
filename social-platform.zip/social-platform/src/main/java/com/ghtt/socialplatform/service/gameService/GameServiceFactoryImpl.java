package com.ghtt.socialplatform.service.gameService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
@Service
@Slf4j
public class GameServiceFactoryImpl implements GameServiceFactory {
    @Autowired
    private Map<String,GameService> gameServiceMap=new ConcurrentHashMap<>();

    public GameService getGameService(String gameName) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
       GameService service= gameServiceMap.get(gameName);
       if(null==service){log.error("未发现对应的service");
       return null;}
        return service.getClass().getDeclaredConstructor().newInstance();
    }
}
