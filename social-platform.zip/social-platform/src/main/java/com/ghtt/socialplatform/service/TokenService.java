package com.ghtt.socialplatform.service;

import com.ghtt.socialplatform.domain.User;

public interface TokenService {
    String prikey="ku3is8ILdI165SD8d903UUdsnlZox53sxXKdtuxcn9892wtG";
    String getToken(User user);
    String getRefreshToken(User user);
    void expireToken(String token);
    boolean banned(String token);

}
