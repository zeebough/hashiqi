package com.ghtt.socialplatform.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ghtt.socialplatform.domain.User;
import org.apache.ibatis.annotations.*;


@Mapper
public interface UserDao extends BaseMapper<User>{
    @Select("select * from user where userId=#{userId}")
    @Results({@Result(property = "password", column = "pwd")})
    User selectUserWithPwdById(Long userId);

    @Select("select * from user where phone=#{phone}")
    @Results({@Result(property = "password", column = "pwd")})
    User selectUserWithPwdByPhone(String phone);

    @Select("select userId,pwd as password from user where phone=#{phone}")
    User selectIdAndPwdByPhone(String phone);

    @Update("update user set isPrivate = 1 where userId = #{userId}")
    int setPrivate(Long userId);

    @Update("update user set isPrivate = 0 where userId = #{userId}")
    int setPublic(Long userId);
}
