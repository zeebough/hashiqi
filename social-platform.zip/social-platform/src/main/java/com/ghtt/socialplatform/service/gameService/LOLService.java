package com.ghtt.socialplatform.service.gameService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ghtt.socialplatform.domain.games.LOL;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service("lol")
public class LOLService extends AttributeMapGameService<LOL>{
        /*
        for (String key:paramMap.keySet()
             ) {
            switch (key) {
                case "userId" -> entity.setUserId(Long.parseLong(paramMap.get("userId")));
                case "zone" -> entity.setZone(paramMap.get("zone"));
                case "gameId" -> entity.setGameId(paramMap.get("gameId"));
                case "ranking" -> entity.setRanking(paramMap.get("ranking"));
                case "position" -> entity.setPosition(paramMap.get("position"));
                case "des" -> entity.setDes(paramMap.get("des"));
                default -> log.error("字段不存在");
            }
        }
        System.out.println(dao.insert(entity));
         */

    @Override
    public List<LOL> selectPlayer() {
        QueryWrapper<LOL> wrapper=new QueryWrapper<>();
        wrapper.lambda().eq(paramMap.containsKey("zone"),LOL::getZone,paramMap.get("zone"))
                        .like(paramMap.containsKey("position"),LOL::getPositions,paramMap.get("position"))
                        .eq(paramMap.containsKey("ranking"),LOL::getRanking,paramMap.get("ranking"));
        return dao.selectList(wrapper);
    }
}
