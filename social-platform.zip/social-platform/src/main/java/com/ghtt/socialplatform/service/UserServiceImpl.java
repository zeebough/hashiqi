package com.ghtt.socialplatform.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ghtt.socialplatform.controller.Code;
import com.ghtt.socialplatform.controller.exceptions.BusinessException;
import com.ghtt.socialplatform.dao.UserDao;
import com.ghtt.socialplatform.domain.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Slf4j
@Service
public class UserServiceImpl implements UserService{
    @Autowired
    UserDao userDao;

    @Override
    public void register(String phone, String password, String nickName){
        if(phone==null||phone.trim().equals(""))throw new BusinessException(Code.INSERT_ERR,"手机号不能为空");
        if(password==null||password.trim().equals(""))throw new BusinessException(Code.INSERT_ERR,"密码不能为空");
        if(nickName==null||nickName.trim().equals(""))throw new BusinessException(Code.INSERT_ERR,"昵称不能为空");
        User existUser=userDao.selectIdAndPwdByPhone(phone);
        if(null!=existUser) throw new BusinessException(Code.INSERT_ERR,"该手机号已被注册");

        User userForRegister = new User(phone,password,nickName);
        if(addUser(userForRegister)<1)throw new BusinessException(Code.INSERT_ERR,"注册失败，请检查所填信息或稍后再试");
    }

    @Override
    public User login(String phone, String password){
        if(phone==null||phone.trim().equals(""))throw new BusinessException(Code.SELECT_ERR,"手机号不能为空");
        if(password==null||password.trim().equals(""))throw new BusinessException(Code.SELECT_ERR,"密码不能为空");

        User user=userDao.selectIdAndPwdByPhone(phone);
        if(user==null)throw new BusinessException(Code.SELECT_ERR,"用户不存在");
        if(!user.getPassword().equals(password))throw new BusinessException(Code.SELECT_ERR,"密码错误");
        return user;
    }

    @Override
    public User selectUserById(Long id) {
        return userDao.selectById(id);
    }

    @Override
    public List<User> selectUserByName(String userName) {
        return userDao.selectList(new QueryWrapper<User>().like("userName",userName));
    }

    @Override
    public int addUser(User user) {
        return userDao.insert(user);
    }

    @Override
    public int updateUserById(User user) {
       return userDao.updateById(user);
    }

    @Override
    public User selectUserByPhone(String phone) {
        QueryWrapper<User> wrapper=new QueryWrapper<>();
        wrapper.eq("phone",phone);
        return userDao.selectOne(wrapper);
    }

    @Override
    public List<User> selectAllUsers(long current,long size) {
        Page<User> userPage=new Page<>(current,size);
        return userDao.selectPage(userPage,null).getRecords();
    }

    @Override
    public List<User> selectAllUsers() {
        return userDao.selectList(null);
    }

    @Override
    public int deleteUser(User user) {
        return userDao.deleteById(user.getUserId());
    }

    @Override
    public int setPrivate(Long userId) {
        return userDao.setPrivate(userId);
    }

    @Override
    public int setPublic(Long userId) {
        return userDao.setPublic(userId);
    }
}
