package com.ghtt.socialplatform.domain.multitable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserHoldBlacklist {
    private Long holderId;
    private Long memberId;
}
