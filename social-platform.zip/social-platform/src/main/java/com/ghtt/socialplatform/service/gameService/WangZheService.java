package com.ghtt.socialplatform.service.gameService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ghtt.socialplatform.domain.games.WangZhe;
import org.springframework.stereotype.Service;

import java.util.List;
//同表名
@Service("wang_zhe")
public class WangZheService extends AttributeMapGameService<WangZhe> {
    public WangZheService(){
        this.c=WangZhe.class;
    }

    @Override
    public List<WangZhe> selectPlayer() {
        QueryWrapper<WangZhe> wrapper=new QueryWrapper<>();
        wrapper.lambda().eq(paramMap.containsKey("zone"),WangZhe::getZone,paramMap.get("zone"))
                .like(paramMap.containsKey("position"),WangZhe::getPositions,paramMap.get("position"))
                .eq(paramMap.containsKey("ranking"),WangZhe::getRanking,paramMap.get("ranking"));
        return dao.selectList(wrapper);
    }
}
