package com.ghtt.socialplatform.domain.games;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Getter;
import lombok.Setter;

//TODO:多选框结果String和String互换应由前端完成，因为Map<String,String>不能一个key对应多个value
//BaseMapper中insert返回的int是sql影响的行数
public abstract class Game {

}
