package com.ghtt.socialplatform.service.gameService;

import com.ghtt.socialplatform.domain.games.Game;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

public interface GameService<T extends Game> {
    void setParams(Map<String,String> params);
    int addPlayer()throws Exception;
    int deletePlayer();
    int updatePlayer() throws Exception;
    List<T> selectPlayer();
    T bindData2Entity() throws Exception;
}
