package com.ghtt.socialplatform.service;

import com.ghtt.socialplatform.domain.User;

import java.util.List;

public interface UserService {
    User selectUserById(Long id);

    List<User> selectUserByName(String userName);

    void register(String phone, String password, String nickName);

    User login(String phone, String password);

    int addUser(User user);

    int updateUserById(User user);

    User selectUserByPhone(String phone);

    List<User> selectAllUsers(long current, long size);

    @Deprecated
    List<User> selectAllUsers();

    int deleteUser(User user);

    int setPrivate(Long userId);

    int setPublic(Long userId);
}
