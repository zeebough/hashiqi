package com.ghtt.socialplatform.service.gameService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ghtt.socialplatform.domain.games.MC;
import org.springframework.stereotype.Service;

import java.util.List;
@Service("mc")
public class MCService extends AttributeMapGameService<MC>{
    public MCService(){
        this.c=MC.class;
    }
    @Override
    public List<MC> selectPlayer() {
        QueryWrapper<MC> wrapper=new QueryWrapper<>();
        return null;
    }
}
