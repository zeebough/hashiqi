package com.ghtt.socialplatform.global;

import java.util.UUID;

public class ServerProperties {
//  内部请求转发使用的ID，防止私有资源被外部访问
    public static final String INTERNAL_SERVER_REQUEST= UUID.randomUUID().toString();
//    签发token时使用的ID
    public static final String TOKEN_ISSUER= UUID.randomUUID().toString();
}
