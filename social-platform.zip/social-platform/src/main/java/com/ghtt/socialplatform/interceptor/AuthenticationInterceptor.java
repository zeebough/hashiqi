package com.ghtt.socialplatform.interceptor;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;
import com.ghtt.socialplatform.controller.Code;
import com.ghtt.socialplatform.controller.exceptions.BusinessException;
import com.ghtt.socialplatform.domain.User;
import com.ghtt.socialplatform.global.ServerProperties;
import com.ghtt.socialplatform.service.TokenService;
import com.ghtt.socialplatform.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;


public class AuthenticationInterceptor implements HandlerInterceptor {
    @Autowired
    UserService userService;
    @Autowired
    TokenService tokenService;

    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object handler) throws IOException, ServletException {

        httpServletRequest.setCharacterEncoding("UTF-8");
        httpServletResponse.setCharacterEncoding("UTF-8");
        String token = httpServletRequest.getHeader("token");// 从 http 请求头中取出 token
        // 执行认证
        if (null == token) {
            throw new BusinessException(Code.INVALID_TOKEN,"无token，请重新登录");
        }
        if(!tokenService.banned(token)){
            throw new BusinessException(Code.INVALID_TOKEN,"token被禁，请重新登录");
        }

        // 获取 token 中的信息
        Date currentTime=new Date();
        String issuer;
        String type;
        String userId;
        Date iss;
        Date exp;
        JWTVerifier jwtVerifier = JWT.require(Algorithm.HMAC256(TokenService.prikey)).build();
        try {
            DecodedJWT decodedJWT=jwtVerifier.verify(token);
            issuer=decodedJWT.getIssuer();
            type=decodedJWT.getClaim("type").asString();
            userId= decodedJWT.getAudience().get(0);
            iss= decodedJWT.getIssuedAt();
            exp= decodedJWT.getExpiresAt();
        } catch (JWTVerificationException e) {
            throw new BusinessException(Code.INVALID_TOKEN,"token验证错误");
        }
        if(!ServerProperties.TOKEN_ISSUER.equals(issuer)){
            throw new BusinessException(Code.INVALID_TOKEN,"token签发者非法");
        }
        if (currentTime.before(iss)) {
            throw new BusinessException(Code.INVALID_TOKEN,"token签发时间非法");
        }
        if (currentTime.after(exp)) {
            throw new BusinessException(Code.INVALID_TOKEN,"token已过期，请重新登录");
        }
        switch (type) {
            case "access":
                User user = userService.selectUserById(Long.valueOf(userId));//NumberFormatException
                if (null == user) {
                    throw new BusinessException(Code.SELECT_ERR,"用户不存在，请重新登录");
                }
                httpServletRequest.setAttribute("userId",userId);
                return true;

            case "refresh":
                User userForRefresh = new User();
                userForRefresh.setUserId(Long.valueOf(userId));
                String newToken=tokenService.getToken(userForRefresh);
                MyHttpRequestWrapper wrapper = new MyHttpRequestWrapper(httpServletRequest);
                wrapper.addHeader("Referer",ServerProperties.INTERNAL_SERVER_REQUEST);
                wrapper.setAttribute("newToken",newToken);
                wrapper.getRequestDispatcher("/refresh").forward(wrapper,httpServletResponse);
                return true;

            default:
                return false;
        }
    }

}

